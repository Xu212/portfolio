﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _2018
{
    class Program
    {
        static void Main(string[] args)
        {
            //fájl beolvasása
            List<emberek> főlista = new List<emberek>();
            string[] tomb = File.ReadAllLines(@"C:\Users\matex\Desktop\érettségi\2018\4_Tarsalgo\ajto.txt");
            foreach (string egyelem in tomb)
            {
                string[] adatok = egyelem.Split(' ');
                főlista.Add(new emberek(Convert.ToInt32(adatok[0]), Convert.ToInt32(adatok[1]), Convert.ToInt32(adatok[2]), Convert.ToString(adatok[3])));

            }
            //2.feladat
            /*Írja a képernyőre annak a személynek az azonosítóját, aki a vizsgált időszakon belül először
            lépett be az ajtón, és azét, aki utoljára távozott a megfigyelési időszakban! */
            Console.WriteLine("2.feladat");
            List<emberek> elso_be = főlista.FindAll(q => q.tartozkodas == "be");
            List<emberek> elso_ki = főlista.FindAll(q => q.tartozkodas == "ki");
            Console.WriteLine("Első aki belépett: " + elso_be.First().ID + " Utolsó aki kiment: " + elso_ki.Last().ID);

            /*Határozza meg a fájlban szereplő személyek közül, ki hányszor haladt át a társalgó ajtaján!
             A meghatározott értékeket azonosító szerint növekvő sorrendben írja az athaladas.txt
             fájlba! Soronként egy személy azonosítója, és tőle egy szóközzel elválasztva az áthaladások
             száma szerepeljen!*/
            //3.feladat

            //Fájlba irás for máté
            //Step 1: Gondoljuk át mi lesz egy sorban
            //Step 2: Gondoljuk át hány sor lesz a fájlban
            //Step 3: Csináljunk egy tömböt ami annyi elemet tud tartlamazni ahány sor lesz
            //Step 4: Töltsük fel ezt a tömböt a sorokkal
            //Step 5: Irjuk ki a tömböt WriteAllLines-al

            List<int> IDk = főlista.Select(ajto_elem => ajto_elem.ID).Distinct().OrderBy(hjugfjhbnuf => hjugfjhbnuf).ToList();
            string[] kiirandosorok = new string[IDk.Count];
            for (int i = 0; i < IDk.Count; i++)
            {
                kiirandosorok[i] = IDk[i].ToString() + " " + főlista.FindAll(h => h.ID == IDk[i]).Count;
            }
            File.WriteAllLines(@"C:\Users\matex\Desktop\érettségi\2018\4_Tarsalgo\athaladas.txt", kiirandosorok);


            //4.feladat
            //Írja a képernyőre azon személyek azonosítóját, akik a vizsgált időszak végén a társalgóban tartózkodtak!
            for (int i = 0; i < IDk.Count; i++)
            {
                if (főlista.FindAll(h => h.ID == IDk[i]).Count % 2 != 0)
                {
                    Console.Write(IDk[i].ToString() + " ");
                }
            }

            //5.feladat
            //Hányan voltak legtöbben egyszerre a társalgóban? Írjon a képernyőre egy olyan (óra: perc), amikor a legtöbben voltak bent!
            int legtobb = 0;
            int hányembervanbent = 0;
            int maxora = 0;
            int maxperc = 0;
            foreach (emberek bejegyzes in főlista)
            {
                if (bejegyzes.tartozkodas == "be")
                {
                    ++hányembervanbent;
                }
                else
                {
                    --hányembervanbent;
                }
                if (legtobb < hányembervanbent)
                {
                    maxora = bejegyzes.ora;
                    maxperc = bejegyzes.perc;
                }
                legtobb = Math.Max(legtobb, hányembervanbent);

            }
            Console.WriteLine($"\nPéldául {maxora}:{maxperc} ");
            //6.feladat
            //Kérje be a felhasználótól egy személy azonosítóját! A további feladatok megoldásánál ezt használja fel!
            //Feltételezheti, hogy a megadott azonosítóhoz tartozik adat a forrásfájlban. 

            Console.WriteLine("ID: ");
            int megadottID = Convert.ToInt32(Console.ReadLine());
            List<emberek> megadottidlistaja = főlista.FindAll(h => h.ID == megadottID);
            /*            int ev = 1900;
            int ho = 12;
            int nap = 12;
            DateTime kesobbi = new DateTime(ev, ho, nap, 20, 38, 0);
            DateTime korabbi = new DateTime(ev, ho, nap, 15, 28, 0);
            TimeSpan kulonbseg = kesobbi - korabbi;
            Console.WriteLine(kulonbseg.TotalSeconds/60);*/
            //7.Írja a képernyőre, hogy a beolvasott azonosítóhoz tartozó személy mettől meddig tartózkodott a társalgóban!
            foreach (emberek sor in megadottidlistaja)
            {
                string perc = sor.perc.ToString();
                if (sor.perc < 10)
                {
                    perc = "0" + perc;
                }
                if (sor.tartozkodas == "be")
                {
                    Console.Write($"{sor.ora}:{perc} - ");
                }
                if (sor.tartozkodas == "ki")
                {
                    Console.Write($"{sor.ora}:{perc}\n");
                }
            }
            /*Határozza meg, hogy a megfigyelt időszakban a beolvasott azonosítójú személy összesen
            hány percet töltött a társalgóban!
            Írja ki, hogy a beolvasott azonosítójú személy mennyi időt volt a társalgóban, és a megfigyelési
            időszak végén bent volt - e még!*/
            //Párosával megyünk (kettesével) a listán végig
            //kivonjuk a későbbit a korábbiból
            //Ha nincsen későbbi (a jeleneleginél) akkor az utolsó egyedül van (és minden ami ebből következik)
            int eltoltottido = 0;
            int ev = 1;
            int honap = 1;
            int nap = 1;
            for (int i = 0; i < megadottidlistaja.Count; i=i+2)
            {
                /* megadottidlistaja[i].ora;*/
                DateTime korabbi = new DateTime(ev, honap, nap, megadottidlistaja[i].ora, megadottidlistaja[i].perc, 0);
                if (i == megadottidlistaja.Count - 1)
                {

                    Console.WriteLine("bent van");
                }
                else 
                {
                    DateTime kesobbi = new DateTime(ev, honap, nap, megadottidlistaja[i+1].ora, megadottidlistaja[i+1].perc, 0);
                    eltoltottido = eltoltottido + Convert.ToInt32((kesobbi - korabbi).TotalMinutes);
                }
            }
            Console.WriteLine(eltoltottido);


        
            Console.ReadKey();
        }
    }
    class emberek
    {
        public int ora;
        public int perc;
        public int ID;
        public string tartozkodas;
        public emberek(int hour, int minute, int id, string be)
        {
            ora = hour;
            perc = minute;
            ID = id;
            tartozkodas = be;
        }
    }

}
