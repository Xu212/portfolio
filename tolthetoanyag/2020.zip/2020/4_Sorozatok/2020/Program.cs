﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace _2020
{
    class Program
    {
        static void Main(string[] args)
        {
            List<sorozat> folista = new List<sorozat>();

            string[] readedlist = File.ReadAllLines(@"C:\Users\matex\Desktop\érettségi\2020\4_Sorozatok\lista.txt");
            for (int i = 0; i < readedlist.Length; i = i + 5)
            {
                folista.Add(new sorozat(readedlist[i], readedlist[i + 1], readedlist[i + 2], Convert.ToInt32(readedlist[i + 3]), Convert.ToBoolean(Convert.ToInt32(readedlist[i + 4]))));
            }

            //2.feladat
            //2. Írassa ki a képernyőre, hogy hány olyan epizód adatait tartalmazza a fájl, amelynek ismert az adásba kerülési dátuma!
            List<sorozat> knownrelease = folista.FindAll(h => h.megjelenes != new DateTime(1,1,1));
            Console.WriteLine(knownrelease.Count);

            //3.feladat
            //3. Határozza meg, hogy a fájlban lévő epizódok hány százalékát látta már a listát rögzítő személy! A százalékértéket a minta szerint, két tizedesjeggyel jelenítse meg a képernyőn!
            List<sorozat> saw = folista.FindAll(h => h.watched == true);
            double percent = Convert.ToDouble(saw.Count) / Convert.ToDouble(folista.Count) * 100;
            Console.WriteLine(Math.Round(percent, 2) + "%");

            //4.feladat
            //4. Számítsa ki, hogy összesen mennyi időt töltött a személy az epizódok megnézésével! Az eredményt a minta szerint nap, óra, perc formában adja meg!
            List<int> timespent = saw.Select(h => h.idotartam).ToList();
            // osszeg += ertek : osszeg = osszeg + ertek
            int sum = timespent.Aggregate((summa, jelenlegi) => summa = summa + jelenlegi);
            Console.WriteLine(sum);
            TimeSpan eltoltottido = new TimeSpan(0,sum,0);
            Console.WriteLine($"{eltoltottido.Days} {eltoltottido.Hours} {eltoltottido.Minutes}");
            /*5. Kérjen be a felhasználótól egy dátumot „éééé.hh.nn” formában! Határozza meg, hogy
            az adott dátumig megjelent epizódokból melyeket nem látta még! Az aznapi epizódokat is
            számolja bele!A feltételnek megfelelő epizódok esetén írja a képernyőre tabulátorral
            elválasztva az évad - és az epizódszámot, valamint a sorozat címét a minta szerint!*/
            Console.Write("Dátum év,hónap és nap formájában:");
            string bekertdatum = Convert.ToString(Console.ReadLine());
            bekertdatum.Substring(0, 4);
            DateTime rendesdatum = new DateTime(Convert.ToInt32(bekertdatum.Substring(0, 4)), Convert.ToInt32(bekertdatum.Substring(5, 2)), Convert.ToInt32(bekertdatum.Substring(8, 2)));
            
           List<sorozat> latottsorozat= folista.FindAll(h=>h.megjelenes<=rendesdatum).FindAll(g=>g.watched==false).FindAll(j=>j.megjelenes!= new DateTime(1,1,1));
            foreach (sorozat egysorozat in latottsorozat)
            {
                Console.WriteLine($"{egysorozat.resz}\t{egysorozat.cim}");
            }

            /*6. Készítse el az alábbi algoritmus alapján a hét napját meghatározó függvényt! A függvény
            neve Hetnapja legyen! A függvény az év, hónap és nap megadása után szöveges
            eredményként visszaadja, hogy az adott nap a hét melyik napja volt. (Az a és b egész
            számok maradékos osztása esetén az a div b kifejezés adja meg a hányadost,
            az a mod b pedig a maradékot, például 17 div 7 = 2 és 17 mod 7 = 3.)*/

            /*7. Kérjen be a felhasználótól egy napot az előző feladatban látható rövidített alakban!
            A napokat egy (h, k, p, v), kettő (cs), vagy három (sze, szo) karakterrel adja meg! Határozza
            meg, hogy a fájlban lévő sorozatok közül melyike(ke)t vetítik az adott napon! A sorozatok
            nevét a minta szerint jelenítse meg a képernyőn! Ha az adott napon egy sorozatot sem adtak
            adásba, akkor „Az adott napon nem kerül adásba sorozat.” üzenetet jelenítse meg! */
            Console.Write("adjon meg egy napot:");
            string megadottnap = Convert.ToString(Console.ReadLine());
            List<string> sorozatnap= knownrelease.FindAll(h => hetnapja(h.megjelenes.Year, h.megjelenes.Month, h.megjelenes.Day) == megadottnap).Select(d=>d.cim).Distinct().ToList();
            if (sorozatnap.Count>0)
            {
                for (int i = 0; i < sorozatnap.Count; i++)
                {
                    Console.WriteLine(sorozatnap[i]);
                }
            }
            else
            {
                Console.WriteLine("Az adott napon nem kerül adásba sorozat.");
            }

            /*8.Határozza meg sorozatonként az epizódok összesített vetítési idejét és az epizódok számát!
            A számításnál vegye figyelembe a vetítési dátummal nem rendelkező epizódokat is !
            A megoldás során felhasználhatja, hogy egy sorozat epizódjainak adatai egymást követik
            a forrásállományban.A listát írja ki a summa.txt fájlba!A fájl egy sorában a sorozat címe,
            az adott sorozatra vonatkozó összesített vetítési idő percben és az epizódok száma
            szerepeljen szóközzel elválasztva!*/
            List<string> sorozat_cimek = folista.Select(h => h.cim).Distinct().ToList();
            string[] sorozattomb = new string[sorozat_cimek.Count];
            for (int i = 0; i < sorozat_cimek.Count; i++)
            {
                sorozattomb[i] = sorozat_cimek[i] + " " + folista.FindAll(h => h.cim == sorozat_cimek[i]).Sum(g=>g.idotartam)+" "+ folista.FindAll(f => f.cim == sorozat_cimek[i]).Count();
            }
            File.WriteAllLines(@"C:\Users\matex\Desktop\érettségi\2020\4_Sorozatok\summa.txt",sorozattomb);
            Console.WriteLine("txt kész van");
            Console.ReadKey();

        }
        static string hetnapja(int ev, int honap, int nap)
        {
            string[] napok = {"v","h","k","sze","cs","p","szo"};
            int[] honapok = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
            if (honap < 3)
            {
                ev = ev - 1;
            }
            string hetnapjai  =napok[(ev + ev / 4 - ev / 100 + ev / 400 + honapok[honap - 1] + nap) % 7];
            return hetnapjai;
        }
    }
    class sorozat
    {
        public DateTime megjelenes;
        public string cim;
        public string resz;
        public int idotartam;
        public bool watched; //false=nem látta, true=látta
        public sorozat(string release, string title, string episode, int min, bool látta)
        {
            if (release == "NI")
            {
                megjelenes = new DateTime(1, 1, 1);
            }
            else
            {
                megjelenes = new DateTime(Convert.ToInt32(release.Substring(0, 4)), Convert.ToInt32(release.Substring(5, 2)), Convert.ToInt32(release.Substring(8, 2)));
            }
            
            cim = title;
            resz = episode;
            idotartam = min;
            watched = látta;
        }
    }

}
