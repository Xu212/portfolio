import szoveg
szoveg.szoveg()
szoveg.kiiratas()
szoveg.karakterek_szama()
