#logikai bevezetés
def szoveg():
    a = None
    print(bool(a))

def kiiratas():
    sz="Ez egy mondat"
    sz2="Ez"
    szam=7
    print("Első karakter: ", sz[0])
    print("Negyedik karakter: ", sz[4])
    print("Utolsó karakter: ", sz[-1])
    print("kettőtől ötig karakter: ", sz[2:5])
    print("Negyediktől: ", sz[4:])
    print("Ötödik előtti karakter: ", sz[:5])
    print(" karakter: ", sz[0:-1:2])
    print("Első karakter: ", sz[::-1])
    print("Első karakter: ", sz[::-2])
    print("Szöveg plusz szám karakter: ", sz+str(szam))
    print("Valahányszor kiírni karaktert: ", sz*3)
def karakterek_szama():
    #1.feladat
    szo=input("Kérek egy szöveget: ")
    print("A szöveg hossza:",len(szo))
    #2.feladat
    szam=int(input("Adja meg, hogy hányadik karakter érdekli önt: "))
    if(szam>len(szo)):
        print("Ilyen karakter nincs")
    else:
        print(szo[szam-1])