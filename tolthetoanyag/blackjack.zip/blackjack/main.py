import reszletek
import random
reszletek.jatek()