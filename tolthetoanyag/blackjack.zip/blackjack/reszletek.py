import random
def kezdolista():
    lista = [None] * 36
    szam = 2
    noveles=1
    for i in range(len(lista)):
        lista[i] = szam
        if noveles % 4 == 0:
            szam += 1
        noveles += 1
    for i in range(16):
        if i < 4:
            lista.append("J")
        elif i < 8:
            lista.append("Q")
        elif i < 12:
            lista.append("K")
        elif i < 16:
            lista.append("A")
    return lista
def gepe(szoveg = "jatekos"):
    if szoveg == "gép":
        return True
    return False

def betue(kartya = 0):
    if kartya == "J" or kartya == "Q" or kartya == "K":
        kartya = 10
    if kartya == "A":
        kartya = 11
    return kartya
def kinyert(geppontja = 0, jatekospont= 0):
    if geppontja < jatekospont:
        print("\nGratulálunk a játékos nyert")
    elif geppontja > jatekospont:
        print("\nA gép nyert")
    else:
        print("\nDöntetlen.")

def besokla(geppontja = 0, jatekospont = 0):
    if geppontja > 21 and jatekospont > 21:
        print(f"\nMind a két fél besokalt. Játékos:{jatekospont}, Gep:{geppontja}")
    elif geppontja > 21:
        print(f"\nA bank besokalt! Bank pontja:{geppontja}")
    elif jatekospont > 21:
        print(f"\nA játékos sokalt be. Játékos pontja:{jatekospont}")

def kartyaosztas(pont = 0, futas = 2,szoveg="Játékos"):
    lista = kezdolista()
    for i in range(futas):
        kartya = lista[random.randint(0, 51)]
        print(kartya, end=" ")
        kartya = betue(kartya)
        pont += kartya
    if gepe(szoveg):
        print("_")
    print(f"\nKartyák összegek: {pont}")
    return pont

def kereujlaop(pont=0, szoveg= "Játékos"):
    lista = kezdolista()
    if gepe(szoveg):
        ujlap = random.randint(0,1)
        while ujlap == 1 and pont < 21:
            kartya = lista[random.randint(0, 51)]
            print(f"ezt húzta a gép: {kartya}")
            kartya = betue(kartya)
            pont += kartya
            print(f"Gép:{pont}", end=", ")
            ujlap = random.randint(0, 1)
        print(f"Nem kért új lapot a gép. Eredménye: {pont}")
    else:
        ujlap = input(f"\nKérsz-e még 1 lapot? ")
        while ujlap.lower() == "y" or ujlap.lower() == "yes" or ujlap.lower() == "igen" and pont <= 21:
            kartya = lista[random.randint(0, 51)]
            print(f"Ezt húztad: {kartya}")
            kartya = betue(kartya)
            pont += kartya
            print(f"jatekospont:{pont}", end=", ")
            if pont <= 21:
                ujlap = input(f"\nKérsz-e még 1 lapot? ")
        print(f"Nem kért új lapot. Eredménye: {pont}")
    return pont

def jatek():
    jatekospont=0
    geppontja=0
    jatekospont = kartyaosztas(jatekospont)
    geppontja = kartyaosztas(geppontja, 1, "gép")
    jatekospont = kereujlaop(jatekospont)
    print("Gépe nem mutatott lapja:",end=" ")
    geppontja = kartyaosztas(geppontja, 1)
    geppontja = kereujlaop(geppontja, "gép")
    if jatekospont == 21:
        print(f"\nA játékos nyert mivel black jack-el rendelkezik.")
    elif(jatekospont<21 and geppontja<21):
        if jatekospont < 21:
            if(jatekospont > 21 or geppontja >21):
                besokla(geppontja, jatekospont)
            elif(jatekospont<=21 and geppontja<=21):
                kinyert(geppontja, jatekospont)
    else:
        besokla(geppontja, jatekospont)



