def fel1(rendeles = " "):
    vaneg = False
    for i in range(len(rendeles)):
        if rendeles[i].lower() =="g":
            vaneg = True
    return vaneg
def fel2():
    rendeles= input("Adja meg a rendelést: ")
    while not fel1(rendeles):
        rendeles = input("Adja meg rendesen a rendelést: ")
    return rendeles
def fel3(listahossz=3):
    rendelesek = [None]*listahossz
    for i in range(len(rendelesek)):
        rendelesek[i]=fel2()
    return rendelesek
def fel4N():
    rendelesek = fel3(3)
    print(rendelesek)
    db=0
    for i in range(len(rendelesek)):
        for j in range(len(rendelesek[i])):
            if rendelesek[i][j].lower() == "g":
                db+=1
    print(f"Ennyi db Garfield-os palacsintát kell csinálnia: {db}")

