import Dolgozat
Dolgozat.fel4N()