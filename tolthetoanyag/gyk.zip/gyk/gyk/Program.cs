﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace gyk
{
    class Program
    {
    
        static void Main(string[] args)
        {

            List<hasznalat> használatok = new List<hasznalat>(); //lista készítés

            
            string[] nyers = File.ReadAllLines(@"C:\Users\matex\Desktop\érettségi\2019\4_Ceges_autok\autok.txt"); //fájl beolvasás

            foreach (string egynyers in nyers) // egynyers hivatkozott elem
            {
                //"1 08:45 CEG306 501 23989 0" => ["1", "08:45", "CEG306", "501", "23989", "0"]
                string[] adatok = egynyers.Split(' ');//földarabolás
                használatok.Add(new hasznalat(Convert.ToInt32(adatok[0]), adatok[1], adatok[2], Convert.ToInt32(adatok[3]), Convert.ToInt32(adatok[4]),Convert.ToBoolean(Convert.ToInt32(adatok[5]))));
                //használat tömb feltőltése
            }
            //2.feladat
            Console.WriteLine("2.feladat");
            hasznalat sndfel=használatok.FindAll(elem => elem.be==false).Last();

            /* tömb.FindAll(elem => elem.be == false) megfelelője */
            /*List<hasznalat> szurtelemek = new List<hasznalat>();
            foreach(hasznalat elem in használatok)
            {
                if(elem.be == false)
                {
                    szurtelemek.Add(elem);
                }
            }*/

            Console.WriteLine(sndfel.nap+".nap"+" rendszám "+sndfel.rendszam);
            //3.feladat
            Console.WriteLine("3.feladat");
            Console.Write("Nap: ");
            int megadottnap = int.Parse(Console.ReadLine());
            Console.WriteLine("Forgalom a "+megadottnap+".napon");
            for (int i = 0; i < használatok.Count; i++)
            {
                
                if (használatok[i].nap == megadottnap)
                {
                    if (!használatok[i].be )
                    {
                        Console.WriteLine(használatok[i].ido+" "+használatok[i].rendszam+" "+használatok[i].ID+" "+"be");
                    }
                    else 
                    {
                        Console.WriteLine(használatok[i].ido + " " + használatok[i].rendszam + " " + használatok[i].ID + " " + "ki");
                    }
                }
            }
            //4.feladat
            //Adja meg, hogy hány autó nem volt bent a hónap végén a parkolóban!
            List<hasznalat> be = használatok.FindAll(bevitel => bevitel.be == true);
            List<hasznalat> ki = használatok.FindAll(kivitel => kivitel.be == false);
            int rd = 0;
            foreach(hasznalat kimenet in ki)
            {
                bool visszahoztak = false;
                foreach(hasznalat bemenet in be)
                {
                    if(kimenet.rendszam==bemenet.rendszam && használatok.IndexOf(bemenet) > használatok.IndexOf(kimenet))
                    {
                        visszahoztak = true;
                    }

                }
                if (!visszahoztak)
                {
                    rd++;
                }
            }
            Console.WriteLine("Ennyi kocsi volt kint a hónap végén "+rd);
            /*Készítsen statisztikát, és írja ki a képernyőre mind a 10 autó esetén az ebben a hónapban
            megtett távolságot kilométerben! A hónap végén még kint lévő autók esetén az utolsó
            rögzített kilométerállással számoljon! A kiírásban az autók sorrendje tetszőleges lehet. */
            Console.WriteLine("5.feladat");
            List<hasznalat> CEG301 = használatok.FindAll(q => q.rendszam == "CEG301");
            List<hasznalat> CEG302 = használatok.FindAll(q => q.rendszam == "CEG302");
            List<hasznalat> CEG303 = használatok.FindAll(q => q.rendszam == "CEG303");
            List<hasznalat> CEG304 = használatok.FindAll(q => q.rendszam == "CEG304");
            List<hasznalat> CEG305 = használatok.FindAll(q => q.rendszam == "CEG305");
            List<hasznalat> CEG306 = használatok.FindAll(q => q.rendszam == "CEG306");
            List<hasznalat> CEG307 = használatok.FindAll(q => q.rendszam == "CEG307");
            List<hasznalat> CEG308 = használatok.FindAll(q => q.rendszam == "CEG308");
            List<hasznalat> CEG309 = használatok.FindAll(q => q.rendszam == "CEG309");
            List<hasznalat> CEG300 = használatok.FindAll(q => q.rendszam == "CEG300");

            Console.WriteLine("CEG300: " + (CEG300.Last().km - CEG300.First().km) + "km");
            Console.WriteLine("CEG301: " + (CEG301.Last().km - CEG301.First().km) + "km");
            Console.WriteLine("CEG302: " + (CEG302.Last().km - CEG302.First().km) + "km");
            Console.WriteLine("CEG303: " + (CEG303.Last().km - CEG303.First().km) + "km");
            Console.WriteLine("CEG304: " + (CEG304.Last().km - CEG304.First().km) + "km");
            Console.WriteLine("CEG305: " + (CEG305.Last().km - CEG305.First().km) + "km");
            Console.WriteLine("CEG306: " + (CEG306.Last().km - CEG306.First().km) + "km");
            Console.WriteLine("CEG307: " + (CEG307.Last().km - CEG307.First().km) + "km");
            Console.WriteLine("CEG308: " + (CEG308.Last().km - CEG308.First().km) + "km");
            Console.WriteLine("CEG309: " + (CEG309.Last().km - CEG309.First().km) + "km");

            /*Határozza meg, melyik személy volt az, aki az autó egy elvitele alatt a leghosszabb
            távolságot tette meg! A személy azonosítóját és a megtett kilométert a minta szerint írja a
            képernyőre! (Több legnagyobb érték esetén bármelyiket kiírhatja.) */
            int legtobb=0;
            int azonosito=0;
            //hasznalat: tipus neve
            //kimenet: jelenleg vizsgált eleme a listának
            //ki: lista amin végig megyünk
            /*for(int i = 0; i>ki.Count; i++)
            {
                hasznalat kimenet = ki[i];
            }*/
            Console.WriteLine("6.feladat");
            foreach (hasznalat kimenet in ki)
            {
                int ehhez_a_kimenethez_tartozo_megtett_ut = 0;   
                foreach (hasznalat bemenet in be)
                {
                    if (kimenet.rendszam == bemenet.rendszam && használatok.IndexOf(bemenet) > használatok.IndexOf(kimenet))
                    {
                        ehhez_a_kimenethez_tartozo_megtett_ut=bemenet.km - kimenet.km;
                        if (ehhez_a_kimenethez_tartozo_megtett_ut>legtobb)
                        {
                            legtobb = ehhez_a_kimenethez_tartozo_megtett_ut;
                            azonosito = kimenet.ID;
                        }
                        break;

                    }

                }
                
            }
            Console.WriteLine("Leghosszabb út:"+legtobb+", személy:"+azonosito);

            /*Az autók esetén egy havi menetlevelet kell készíteni! Kérjen be a felhasználótól egy
            rendszámot! Készítsen egy X_menetlevel.txt állományt, amelybe elkészíti az adott
            rendszámú autó menetlevelét! (Az X helyére az autó rendszáma kerüljön!) A fájlba
            soronként tabulátorral elválasztva a személy azonosítóját, a kivitel időpontját (nap.
            óra:perc), a kilométerszámláló állását, a visszahozatal időpontját (nap. óra:perc), és
            a kilométerszámláló állását írja a minta szerint! (A tabulátor kódja: '\t'.) 
            */
            Console.Write("Rendszám: ");
            string szam = Convert.ToString(Console.ReadLine());
            List<hasznalat> kocsi_rendszambe = be.FindAll(rend => rend.rendszam == szam);
            List<hasznalat> kocsi_rendszamki = ki.FindAll(kifele => kifele.rendszam == szam);
            string[] hetes = new string[kocsi_rendszambe.Count];
            for (int i = 0; i < kocsi_rendszambe.Count; i++)
            {
                hetes[i] = kocsi_rendszamki[i].ID + "\t" + kocsi_rendszamki[i].nap + "\t" + kocsi_rendszamki[i].ido + '\t' + kocsi_rendszamki[i].km + '\t' + kocsi_rendszambe[i].nap + '\t' + kocsi_rendszambe[i].ido + '\t' + kocsi_rendszambe[i].km;
            }
            File.WriteAllLines (@"C:\Users\matex\Desktop\érettségi\2019\4_Ceges_autok\" + szam+"_menetlevel.txt",hetes, Encoding.UTF8);
            Console.WriteLine("Menetlevél kész.");
            Console.ReadKey();
        }
    }
    class hasznalat
    {
        public int nap;
        public string ido;
        public string rendszam;
        public int ID;
        public int km;
        public bool be; //true=be false=ki
        public hasznalat(int day, string time, string cn, int id, int Km, bool Be)
        {
            nap = day;
            ido = time;
            rendszam = cn;
            ID = id;
            km = Km;
            be = Be;
            

        }
    }
    
    
}
