﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace hianyzasok
{
    class Program
    {
        static void Main(string[] args)
        {
            List<naplo> mainlist = new List<naplo>();
            string[] nyers = File.ReadAllLines(@"C:\Users\matex\Desktop\érettségi\2017\4_Hianyzasok\naplo.txt");
            int listmonth=0;
            int listday=0;
            foreach (string egynyers in nyers)
            { 
                string[] egyadat = egynyers.Split(' ');
                if (egynyers.Contains("#"))
                {
                    listmonth = Convert.ToInt32(egyadat[1]);
                    listday = Convert.ToInt32(egyadat[2]);
                }
                else
                {
                    mainlist.Add(new naplo(listmonth, listday,egyadat[0], egyadat[1], egyadat[2]));
                }
            }
            /*for (int i = 0; i < mainlist.Count; i++)
            {
                Console.WriteLine($"{mainlist[i].honap} {mainlist[i].nap} {mainlist[i].vezeték} {mainlist[i].kereszt} {mainlist[i].hianyzas}");
            }*/

            List<string> hianyzasok = mainlist.Select(h => h.hianyzas).ToList();
            Console.WriteLine(hianyzasok.Count);
            int igazolt = 0;
            int igazolatlan = 0;
            for (int i = 0; i < hianyzasok.Count; i++)
            {
               igazolt=igazolt+hianyzasok[i].Where(h=>h=='X').Count();
               igazolatlan=igazolatlan+hianyzasok[i].Where(g => g == 'I').Count();
            }
            Console.WriteLine($"{igazolatlan} {igazolt}");

            Console.Write("hónap");
            int bekertho = Convert.ToInt32(Console.ReadLine());
            Console.Write("nap");
            int bekertnap = Convert.ToInt32(Console.ReadLine());
            string aznap=hetnapja(bekertho, bekertnap);
            Console.WriteLine(aznap);

            Console.Write("nap neve: ");
            string bekertday = Convert.ToString(Console.ReadLine());
            Console.Write("melyik óra: ");
            int bekertóra = Convert.ToInt32(Console.ReadLine());
            List<naplo> aznapihiany = mainlist.FindAll(h => hetnapja(h.honap, h.nap) == bekertday);
            int hianyok = aznapihiany.Select(h => h.hianyzas.Substring(bekertóra, 1) == "X").Count() + aznapihiany.Select(h => h.hianyzas.Substring(bekertóra, 1) == "I").Count();
            Console.WriteLine(hianyok);
            Console.ReadKey();
        }
        static string hetnapja(int honap, int nap)
        {
            string[] napnev = { "vasarnap","hetfo", "kedd", "szerda", "csutortok","pentek", "szombat" };
            int[] napszam = { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 335 };
            int napsorszam = (napszam[honap - 1] + nap) % 7;
            string hetnap = napnev[napsorszam];
            return hetnap;
        }
    }
    class naplo
    {
       public int honap;
       public int nap;
       public string vezeték;
       public string kereszt;
       public string hianyzas; //o=jelen volt, i=igazolatlan, x=igazolt
        public naplo(int month, int day, string lastname, string firstname, string absent)
        {
            honap = month;
            nap = day;
            vezeték = lastname;
            kereszt = firstname;
            hianyzas = absent;
        }
    }
}
