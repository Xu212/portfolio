def tizenot(hatar= -15, listahossza = 5):
    lista = [None]*listahossza
    for i in range(len(lista)):
        szam = int(input("Adjon meg egyszámot: "))
        lista[i]= szam
    if max(lista) > hatar:
        legkisebb = max(lista)
        for i in range(len(lista)):
            if legkisebb > lista[i] and lista[i] > hatar:
                legkisebb = lista[i]
                print(lista)
                print(f"A legkisebb és {hatar}-nél/nál nagyobb szám: {legkisebb}")
    else:
        print("Nincs ilyen szám")
