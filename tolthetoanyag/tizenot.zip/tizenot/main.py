import legkisebbkor

legkisebbkor.tizenot()